<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Marvel Cinematic Universe</title>
    <link  rel="stylesheet" href="css/2.css" type="text/css">
</head>
<body>

<img src="image/log.png" alt="#" width="216" height="120" >
<div class="wenzi">
  <p align="right"><a href="web/reg.php" target="_blank">注册 </a>|<a href="web/login.php" target="_blank"> 登陆 </a></p>
	</div>
    
    <br/>
    
<div id="right"  style="background-color:#000">
     <a href="
     index.php">首页</a>
     <a href="web/第一阶段宇宙.html">第一阶段宇宙</a>
     <a href="web/第二阶段宇宙.html">第二阶段宇宙</a>
     <a href="https://mp.weixin.qq.com/s/w0fD0tgLw2y7KRmJCqa7wg
" target="_blank">微信推文</a>
      <a href="web/打地鼠.html" target="_blank">休闲一刻</a>
</div>
	<br/><br/>
<form action="http://www.baidu.com/baidu" target="_blank">
      <table height="40" align="center"><tr><td height="36">
          <input name="tn" type="hidden" value="SE_zzsearchcode_shhzc78w">
          <a href="http://www.baidu.com/"></a>
<input type="text"  name="word" size="40" baidusug="2">
          <input type="submit"  value="百度搜索" >
  </td></tr></table>
    </form>
	<br/><br/>

<div class="gad">
	<div class="xiao" >
		<a href="https://baike.baidu.com/item/漫威/1552730?fr=aladdin" target="_blank">
		<img src="image/fl0.jpg" width="100%" height="428px" alt="#"></a>
	</div>
		<div class="xiao" >
		<a href="https://baike.baidu.com/item/复仇者联盟/22347?fromtitle=复仇者联盟1&fromid=17606867&fr=aladdin" target="_blank">
		<img src="image/fl1.jpg" width="100%" height="428px" alt="#"></a>
	</div>
		<div class="xiao" >
		<a href="https://baike.baidu.com/item/复仇者联盟2：奥创纪元/15102053?fromtitle=复仇者联盟2&fromid=8060806" target="_blank">
		<img src="image/fl2.jpg" width="100%" height="428px" alt="#"></a>
	</div>
		<div class="xiao" >
		<a href="https://baike.baidu.com/item/复仇者联盟3：无限战争" target="_blank">
		<img src="image/fl3.jpg" width="100%" height="428px" alt="#"></a>
	</div>
  <div class="xiao" >
		<a href="https://baike.baidu.com/item/复仇者联盟4：终局之战?fromtitle=复仇者联盟4&fromid=18732928" target="_blank">
		<img src="image/fl4.jpg" width="100%" height="428px" alt="#"></a>
	</div>
	
	
</div>
<br><br><br><br>
<?php
include('web/notice/footer.php');
?>	

</body>
</html>