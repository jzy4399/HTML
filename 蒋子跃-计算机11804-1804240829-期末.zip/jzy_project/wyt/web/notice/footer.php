<div id="footer" style="height:90px;background-color: #353535;color: #7D7D7D;padding-top: 20px;margin-top: 20px;font-size: 15px;">
    <center>
        <p>
            联系我们:jzy_project<br/>
            工作室地址:武汉纺织大学<br/>
            联系电话：123456789   QQ：2254770934
            招生办邮箱：2254770934@qq.com  
        </p>
    </center>
</div>