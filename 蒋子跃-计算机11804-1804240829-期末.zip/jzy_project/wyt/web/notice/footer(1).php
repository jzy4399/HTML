<div id="footer" style="height:90px;background-color: #353535;color: #7D7D7D;padding-top: 20px;margin-top: 20px;font-size: 15px;">
    <center>
        <p>
            联系我们:GK工作室<br/>
            工作室地址:广东创新科技职业学院6栋404 邮编:523960<br/>
            联系电话：1801050641   传真：1801050643
            招生办邮箱：139650043@qq.com  粤ICP备 1801050622号
        </p>
    </center>
</div>