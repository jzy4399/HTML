<?php include("conn.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link href="css/index.css" rel="stylesheet">
	<link  rel="stylesheet" href="../../css/2.css" type="text/css">
</head>
<body>
<img src="../../image/logo2.png" alt="#" width="219" height="48" >
<div id="right"  style="background-color:#4F2C1F">
     <a href="../../index.php">首页</a>
     <a href="../../web/影视科普.html">影视科普</a>
     <a href="../../web/硬件科普.html">硬件科普</a>
     <a href="https://space.bilibili.com/7161352" target="_blank">个人频道</a>
      <a href="../../web/打地鼠.html" target="_blank">小游戏</a>
</div>
	<br/>
<form action="http://www.baidu.com/baidu" target="_blank">
      <table height="40" align="center"><tr><td height="36">
          <input name="tn" type="hidden" value="SE_zzsearchcode_shhzc78w">
          <a href="http://www.baidu.com/"></a>
<input type="text"  name="word" size="40" baidusug="2">
          <input type="submit"  value="百度搜索" >
  </td></tr></table>
    </form>
	<br/><br/><br/><br/>
<div class="content">
    <div class="con_left">
        <div class="con_left1">
           <div class="con_header" style=""><div class="title" style=""><span>技术论坛</span></div></div>
            <div class="">
                <ul><li><a href="add_notice.php">发布论坛帖子</a></li></ul><hr/>
				<ul><li><a href="search_notice.php">搜索论坛内容</a></li></ul><hr/>
                <ul><li><a href="page_notice.php">论坛相关技术内容</a></li></ul><hr/>
				<ul><li><a href="update_notice.php">修改论坛文章内容</a></li></ul><hr/>
				<ul><li><a href="delete_notice.php">删除文章</a></li></ul><hr/>
            </div>
        </div>
    </div>
<div class="con_right">
	<div>
		<div class="blog_list_wrap">
			<div class="con_header"><div class="title"><span>您当前的位置：后台管理系统</span></div></div>
			<div style="margin-top: 20px;margin-bottom: 30px;margin-left: 260px;color:#6DEFD6;font-weight: bold">删除公告信息</div>
			<table class="table1" class=color>
				<tr>
					<td width="180">文章标题</td>
					<td width="397">文章信息</td>
					<td width="55" style="width: 70px">删除文章</td>
				</tr>
				<?php 

				if(@$_GET['page']==""){$_GET['page']=1;}
				if(is_numeric($_GET['page'])){
					$page_size=3;
					$sql="select * from tb_notice";
					$query=mysqli_query($con,$sql);
					$message_count=mysqli_num_rows($query);
					$page_count=ceil($message_count/$page_size);
					$offset=($_GET['page']-1)*$page_size;
					$sql1="select * from tb_notice limit $offset,$page_size";
					$query1=mysqli_query($con,$sql1);
					$row=mysqli_fetch_array($query1);
					if(!$row){
						echo "<font color='red'>暂无公告信息</font>";
					}
					do{
					?>
				<tr>
					<td style="font-size: 14px;"><?php echo $row["title"]; ?></td>
					<td style="font-size: 14px;"><?php echo $row["content"] ?></td>
					<td align="center"><a href="delete_notice_ok.php?id=<?php echo $row["id"]?>"><img src="images/del.png" width="50" height="50" border="0"></a></td>

				</tr>
				<?php 
				}while($row=mysqli_fetch_array($query1));
				}
				?>
			</table>
			<br>
			<table style="width: 100%; font-size: 14px; border: 0px; cellspacing:0px; cellpadding:0px" class="color">
			<tr>

				<td width="37%">&nbsp;&nbsp;页次：<?php echo $_GET['page'];?>/<?php echo $page_count;?>页&nbsp;记录：<?php echo $message_count;?>条&nbsp;</td>
				<td width="63%" align="right">
				<?php  
				if($_GET['page']!=1){
					echo "<a href=delete_notice.php?page=1>首页</a>&nbsp;";
					echo "<a href=delete_notice.php?page=".($_GET['page']-1).">上一页</a>&nbsp;";
				}
				if($_GET['page']<$page_count){
					echo "<a href=delete_notice.php?page=".($_GET['page']+1).">下一页</a>&nbsp;";
					echo "<a href=delete_notice.php?page=".$page_count.">尾页</a>";
				}
				?>
			</tr>
			</table>
		</div>
	</div>
</div>
<div class="clear"></div>
</div><br><br><br>
<?php  
include('footer.php');
?>
</body>
</html>