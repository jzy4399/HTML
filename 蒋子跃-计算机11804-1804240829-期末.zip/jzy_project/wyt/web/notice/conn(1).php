<?php
$con=@mysqli_connect("localhost","root","","wyt")or die("链接数据库失败！");
mysqli_query($con,"set names UTF8");
?>