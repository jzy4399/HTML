<?php include("conn.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php  
	$id=$_GET['id'];
	$sql="delete from tb_notice where id=$id";
	$query=mysqli_query($con,"$sql");
	if($query){
		echo "<script>alert('文章删除成功！');window.location.href='delete_notice.php';</script>";
	}else{
		echo "<script>alert('文章删除失败！');window.location.href='delete_notice.php?';</script>";
	}
	?>
</body>
</html>