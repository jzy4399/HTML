<?PHP include("conn.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link href="css/index.css" rel="stylesheet">
	<link  rel="stylesheet" href="../../css/2.css" type="text/css">
</head>
<body>
<?php
if(isset($_POST["tj"])){
$title = $_POST["title"];              //获取公告标题信息
$content = $_POST["content"];          //获取公告内容信息
date_default_timezone_set("PRC");
$sql="insert into tb_notice(title,content,date)values('".$title."','".$content."','".date('Y-m-d H:i:s')."')";
mysqli_query($con,$sql);
echo "<script language='javascript'>alert('添加公告成功');location.href='page_notice.php';</script>";
}
?>
	
<img src="../../image/logo2.png" alt="#" width="219" height="48" >
<div class="wenzi">
  <p align="right"><?php
if(isset($_SESSION["name"]))
echo $_SESSION["name"];
?></p>
	</div>
    
    <br/>
    
<div id="right"  style="background-color:#4F2C1F">
     <a href="../../index.php">首页</a>
     <a href="../../web/影视科普.html">影视科普</a>
     <a href="../../web/硬件科普.html">硬件科普</a>
     <a href="https://space.bilibili.com/7161352" target="_blank">个人频道</a>
      <a href="../../web/打地鼠.html" target="_blank">小游戏</a>
</div>
	<br/>
<form action="http://www.baidu.com/baidu" target="_blank">
      <table height="40" align="center"><tr><td height="36">
          <input name="tn" type="hidden" value="SE_zzsearchcode_shhzc78w">
          <a href="http://www.baidu.com/"></a>
<input type="text"  name="word" size="40" baidusug="2">
          <input type="submit"  value="百度搜索" >
  </td></tr></table>
    </form>
	<br/><br/><br/><br/>
<div class="content">
    <div class="con_left">
        <div class="con_left1">
           <div class="con_header" style=""><div class="title" style=""><span>技术论坛</span></div></div>
            <div class="">
                <ul><li><a href="add_notice.php">发布论坛帖子</a></li></ul><hr/>
				<ul><li><a href="search_notice.php">搜索论坛内容</a></li></ul><hr/>
                <ul><li><a href="page_notice.php">论坛相关技术内容</a></li></ul><hr/>
				<ul><li><a href="update_notice.php">修改论坛文章内容</a></li></ul><hr/>
				<ul><li><a href="delete_notice.php">删除文章</a></li></ul><hr/>
            </div>
        </div>
    </div>
    <div class="con_right">
        <div class="">
            <div class="">
                <div class="con_header"><div class="title"><span>不耻下问，文明发言！</span></div></div>
                <div style="margin-top:50px;margin-left: 80px;" class="wenzhang">
                    <form name="form1" method="post" action="add_notice.php">
                        <table width="520" height="212" border="0" cellpadding="0" cellspacing="0" bgcolor="#624339">
                            <tr>
                                <td width="87" align="center" class="color">文章题目：</td>
                                <td width="433" height="31"><input name="title" type="text" id="txt_title" size="40" required=""></td>
                            </tr>
                            <tr>
                                <td height="124" align="center" class="color">文章信息：</td>
                                <td><textarea name="content" cols="50" rows="8" id="txt_content" required=""></textarea></td>
                            </tr>
                            <tr>
                                <td height="40" colspan="2" align="center">
                                <input name="tj" type="submit" class="btn_grey" value="发布" >
                                    &nbsp; <input type="reset" name="Submit2" value="重置"></td>
                            </tr>
                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>
</div><br><br><br>
<?php
include('footer.php');
?>	
</body>
</html>